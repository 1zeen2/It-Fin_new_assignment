
/**
 * @author asoocool
 */

class ATextBoxEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.ATextBoxEvent = ATextBoxEvent;




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------

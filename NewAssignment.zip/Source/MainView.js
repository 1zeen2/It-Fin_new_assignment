
class MainView extends AView
{
	constructor()
	{
		super()
        
        /**
         *  0 => default
         *  1 => extend
         */
        this.bottomSheetValue = 0;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
        
        this.infiniteRolling();
        

    }

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

//------------------------------------------------------------------------------------- 무한 스크롤
    /**
     *  무한 스크롤 
     *  this.rolling = setInterval(() => {});
     *  요소 이동이 고정적이라 각 컴포넌트의 크기를 찾아서
     *  그만큼 움직일 수 있도록 변경해야 함
     */
    infiniteRolling() {
        const rollingAreaEl = this.rollingArea.getElement();

        this.rolling = setInterval(() => {
            rollingAreaEl.style.transition = 'transform 0.4s linear'; 
            rollingAreaEl.style.transform = 'translateY(-100px)';
            
            setTimeout(() => {
                rollingAreaEl.style.transition = 'none'; 
                rollingAreaEl.style.transform = 'translateY(0)';
                rollingAreaEl.appendChild(rollingAreaEl.firstElementChild);
            }, 400)

        }, 1200);
    }

	onRollingAreaActionenter(comp, info, e)
	{
        clearInterval(this.rolling);
	}

	onRollingAreaActionleave(comp, info, e)
	{

		this.infiniteRolling();

	}
//------------------------------------------------------------------------------------- 무한 스크롤 끝

//------------------------------------------------------------------------------------- 바텀 시트
    /**
     *  늘어났다 줄어들어야 함
     *      => 상태 값을 읽어서 default, extend 저장하고 기능 수행해야 할 듯
     */
	onBtnBottomSheetControllActionup(comp, info, e)
	{

		this.bottomSheet = this.bottomSheetValue;

        if (this.bottomSheet === 0) {
            this.bottomSheet.setHeight('800px');
        }

	}

//------------------------------------------------------------------------------------- 바텀 시트 끝

}
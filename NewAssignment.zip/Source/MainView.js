
class MainView extends AView
{
	constructor()
	{
		super()
        
        /**
         *  0 => default
         *  1 => extend
         */
        this.bottomSheetValue = 0;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
        
        this.infiniteRolling();
        this.timerReset();
        
    }

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

//------------------------------------------------------------------------------------- 무한 스크롤
    /**
     *  무한 스크롤 
     *  this.rolling = setInterval(() => {});
     *  요소 이동이 고정적이라 각 컴포넌트의 크기를 찾아서
     *  그만큼 움직일 수 있도록 변경해야 함
     */
    infiniteRolling() {
        const rollingAreaEl = this.rollingArea.getElement();

        this.rolling = setInterval(() => {
            rollingAreaEl.style.transition = 'transform 0.4s linear'; 
            rollingAreaEl.style.transform = 'translateY(-100px)';
            
            setTimeout(() => {
                rollingAreaEl.style.transition = 'none'; 
                rollingAreaEl.style.transform = 'translateY(0)';
                rollingAreaEl.appendChild(rollingAreaEl.firstElementChild);
            }, 400)

        }, 1200);
    }

	onRollingAreaActionenter(comp, info, e)
	{
        clearInterval(this.rolling);
	}

	onRollingAreaActionleave(comp, info, e)
	{

		this.infiniteRolling();

	}
//------------------------------------------------------------------------------------- 무한 스크롤 끝

//------------------------------------------------------------------------------------- 바텀 시트
    /**
     *  늘어났다 줄어들어야 함
     *      => 상태 값을 읽어서 default, extend 저장하고 기능 수행해야 할 듯
     *      => 부드럽게 늘어나야 하는데 taransform을 어떻게 적용시킬 것인가
     * 
     *      => 눌렀을 때 값이 있고, 이동 거리가 100 보다 크거나 작으면(100px 이상 위 또는 아래로 움직이면) moveBottomSheet
     * 
     *      => 드래그 하면 드래그 한 만큼 오다가 값이 일정 값 이상으로 변하면 700px까지
     * 
     *      => 바텀시트 올라왔을 때 바텀 시트 외의 영역을 클릭하면 내려가게 만들기
     *      => 바텀 시트 넓이를 구해서 그 부분만 제외하고 클릭하게 만들어야 하나?
     * 
     * 
     */

    moveBottomSheet() {
        const bottomSheetEl = this.bottomSheet.getElement();
        const overLayEl = this.overLay.getElement()

        if (this.bottomSheetValue === 0) {
            bottomSheetEl.style.height = '700px';
            this.bottomSheetValue = 1;
            overLayEl.style.display = 'block';
        } else {
            bottomSheetEl.style.height = '30px';
            this.bottomSheetValue = 0;
            overLayEl.style.display = 'none';
        }

    }

    timerReset() {
        this.resetTimer = setTimeout(() => {
            console.log('리셋 타이머 카운트');
            this.startPoint = 0;
            this.dragDistance = 0;
            console.log('startPoint, dragDistance 리셋');
        }, 300);
    }
	
    /**
     *  버튼으로 moveBottomSheet
     */ 
    onBtnBottomSheetControllActionup(comp, info, e)
	{
		this.moveBottomSheet();
	}

    /**
     *  바텀시트가 활성화 된 상태에서
     *  외부 영역을 클릭하면 바텀시트가 내려감
     *  overLay는 z-index = 1, bottomSheet는 z-index = 2로 지정했음.
     *  (bottomSheet active 상태에서 overLay가 확실하게 클릭될 수 있도록)
     */
    onOverLayClick(comp, info, e)
	{
        if (this.bottomSheetValue === 1) {
		    this.moveBottomSheet();
        }
	}

    /**
     *  바텀시트를 클릭했을 때 startPoint 값이 설정
     *  클릭 후 한참 가만히 있다가 드래그 하면 바텀시트가 열리는 현상이 있었음
     *  클릭 후 일정 시간 움직이지 않으면 startPoint값을 reset해서 의도대로 동작하도록 함
     */
    onBottomSheetHeaderActiondown(comp, info, e)
	{

		this.startPoint = e.clientY;
        this.timerReset();

	}

    /**
     * 
     */
	onAView1Actionmove(comp, info, e)
	{
        if (!this.startPoint) return;

        this.dragDistance = this.startPoint - e.clientY;
        console.log('드래그 이동 거리', this.dragDistance);

        if (this.bottomSheetValue === 0 && this.dragDistance > 100) {
            this.moveBottomSheet();
        }
        if (this.bottomSheetValue === 1 && this.dragDistance < -100) {
            this.moveBottomSheet();
        }
	}
//------------------------------------------------------------------------------------- 바텀 시트 끝

}


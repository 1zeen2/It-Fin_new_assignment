
/**
 * @author asoocool
 */

class ACanvasEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.ACanvasEvent = ACanvasEvent;




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------


class MainView extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.bottomArrowShuttle();
        console.log(this.bottomArrowShuttle);

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    bottomArrowShuttle() {
        // const bottomArrowEl = this.iconBottomArrow.getElement();
    }

}

